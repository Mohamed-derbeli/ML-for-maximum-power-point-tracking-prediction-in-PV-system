# Portfolio

Hi, this is my portfolio project. The main file with data is called "Predict a car price in Ukraine_2020.ipynb". There are also two csv tables with data that I used in my work. 

Happy reading!
